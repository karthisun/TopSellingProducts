allUsersData = {
    
color: '#FF9D00',
name: 'All Users',
data: [
  [1562014015407,1000],[1562014016407,873],[1562014017407,460]
],
tooltip: { yDecimals: 0, ySuffix: '', valueDecimals: 0 }

    , zIndex: 20
    , yAxis: 1
};